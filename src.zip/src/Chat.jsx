
import { useState, useEffect, useCallback } from 'react'
import './App.css'

const API_URL = 'http://localhost:8080/api/messages'

function Chat({ groupId, groupName, userName }) {
  const [message, setMessage] = useState('')
  const [messages, setMessages] = useState([])
  const [editingId, setEditingId] = useState(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  // 1. Backend nunchi messages load cheyyadam
  const loadMessages = useCallback(async () => {
    try {
      const response = await fetch(`${API_URL}/${groupId}`)

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`)
      }

      const data = await response.json()

      setMessages(
        data.map((item) => ({
          id: item.id,
          text: item.message,
          sender: item.sender,
          createdAt: item.createdAt
        }))
      )

      setError('')
    } catch (err) {
      console.error('Load messages error:', err)
      setError(`Could not load messages: ${err.message}`)
    }
  }, [groupId])

  // 2. Group change ayinappudu load cheyyadam
  // Prathi 2 seconds ki messages refresh avuthayi
  useEffect(() => {
    setMessages([])
    setMessage('')
    setEditingId(null)

    loadMessages()

    const intervalId = setInterval(() => {
      loadMessages()
    }, 2000)

    return () => clearInterval(intervalId)
  }, [groupId, loadMessages])

  // 3. New message send cheyyadam / existing message update cheyyadam
  async function sendMessage(event) {
    event.preventDefault()

    if (!message.trim() || loading) {
      return
    }

    setLoading(true)
    setError('')

    try {
      const isEditing = editingId !== null

      const url = isEditing
        ? `${API_URL}/${editingId}`
        : API_URL

      const body = isEditing
        ? {
            message: message.trim()
          }
        : {
            sender: userName || 'Guest',
            message: message.trim(),
            groupId: groupId
          }

      const response = await fetch(url, {
        method: isEditing ? 'PUT' : 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(body)
      })

      const responseText = await response.text()

      if (!response.ok) {
        throw new Error(
          `HTTP ${response.status}: ${responseText}`
        )
      }

      setMessage('')
      setEditingId(null)

      await loadMessages()
    } catch (err) {
      console.error('Send message error:', err)
      setError(`Could not save message: ${err.message}`)
    } finally {
      setLoading(false)
    }
  }

  // 4. Message edit cheyyadaniki
  function editMessage(item) {
    setMessage(item.text)
    setEditingId(item.id)
    setError('')
  }

  // 5. Message delete cheyyadaniki
  async function deleteMessage(id) {
    const confirmed = window.confirm(
      'Are you sure you want to delete this message?'
    )

    if (!confirmed) {
      return
    }

    setError('')

    try {
      const response = await fetch(`${API_URL}/${id}`, {
        method: 'DELETE'
      })

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`)
      }

      if (editingId === id) {
        setEditingId(null)
        setMessage('')
      }

      await loadMessages()
    } catch (err) {
      console.error('Delete message error:', err)
      setError(`Could not delete message: ${err.message}`)
    }
  }

  // 6. Chat screen
  return (
    <div className="chat-page">
      <h1>{groupName} Chat</h1>

      <p>Share your questions and learn together!</p>

      <p>
        Logged in as: <strong>{userName || 'Guest'}</strong>
      </p>

      {error && (
        <p role="alert" style={{ color: 'red' }}>
          {error}
        </p>
      )}

      <div className="chat-messages">
        {messages.length === 0 && !error && (
          <p>No messages yet. Start the conversation!</p>
        )}

        {messages.map((item) => {
          const messageTime = item.createdAt
            ? new Date(item.createdAt).getTime()
            : 0

          const canEditOrDelete =
            messageTime > 0 &&
            Date.now() - messageTime >= 0 &&
            Date.now() - messageTime < 15 * 60 * 1000

          return (
            <div className="chat-message" key={item.id}>
              <p>
                <strong>{item.sender}</strong>
              </p>

              <p>{item.text}</p>

              {canEditOrDelete && (
                <>
                  <button
                    type="button"
                    onClick={() => editMessage(item)}
                  >
                    Edit
                  </button>

                  <button
                    type="button"
                    onClick={() => deleteMessage(item.id)}
                  >
                    Delete
                  </button>
                </>
              )}
            </div>
          )
        })}
      </div>

      <form className="chat-form" onSubmit={sendMessage}>
        <input
          type="text"
          value={message}
          onChange={(event) => setMessage(event.target.value)}
          placeholder={`Message in ${groupName}...`}
          required
        />

        <button type="submit" disabled={loading}>
          {loading
            ? 'Please wait...'
            : editingId !== null
              ? 'Update Message'
              : 'Send'}
        </button>

        {editingId !== null && (
          <button
            type="button"
            onClick={() => {
              setEditingId(null)
              setMessage('')
              setError('')
            }}
          >
            Cancel
          </button>
        )}
      </form>
    </div>
  )
}

export default Chat
