
import { useState } from 'react'
import './App.css'
import Login from './Login.jsx'
import Groups from './Groups.jsx'
import Chat from './Chat.jsx'

function App() {
  const [showGroups, setShowGroups] = useState(false)
  const [showLogin, setShowLogin] = useState(false)
  const [showChat, setShowChat] = useState(false)

  // Store the current user's name
  const [userName, setUserName] = useState(
    () => localStorage.getItem('studyTogetherUser') || ''
  )

  const [selectedGroup, setSelectedGroup] = useState({
    id: 1,
    name: 'Java Programming'
  })

  function openChat(group) {
    setSelectedGroup(group)
    setShowGroups(false)
    setShowChat(true)
  }

  function saveUserName(name) {
    const trimmedName = name.trim()

    if (!trimmedName) {
      alert('Please enter your name.')
      return
    }

    localStorage.setItem('studyTogetherUser', trimmedName)
    setUserName(trimmedName)
    setShowLogin(false)
  }

  if (showChat) {
    return (
      <div>
        <button
          className="back-btn"
          onClick={() => {
            setShowChat(false)
            setShowGroups(true)
          }}
        >
          ← Back to Groups
        </button>

        <p>Logged in as: <strong>{userName || 'Guest'}</strong></p>

        <Chat
          groupId={selectedGroup.id}
          groupName={selectedGroup.name}
          userName={userName || 'Guest'}
        />
      </div>
    )
  }

  if (showGroups) {
    return (
      <div>
        <button
          className="back-btn"
          onClick={() => setShowGroups(false)}
        >
          ← Back to Home
        </button>

        <Groups onSelectGroup={openChat} />
      </div>
    )
  }

  if (showLogin) {
    return (
      <div className="login-page">
        <button
          className="back-btn"
          onClick={() => setShowLogin(false)}
        >
          ← Back to Home
        </button>

        <form
          onSubmit={(event) => {
            event.preventDefault()
            saveUserName(event.target.userName.value)
          }}
        >
          <h2>Enter Your Name</h2>

          <input
            name="userName"
            type="text"
            placeholder="Enter your name"
            defaultValue={userName}
            required
          />

          <button type="submit">Continue</button>
        </form>
      </div>
    )
  }

  return (
    <div className="app">
      <header className="navbar">
        <h2>StudyTogether</h2>

        <nav>
          <a href="#home">Home</a>
          <a href="#groups">Study Groups</a>
          <a href="#about">About</a>
        </nav>

        <button
          className="login-btn"
          onClick={() => setShowLogin(true)}
        >
          {userName ? userName : 'Login'}
        </button>
      </header>

      <section className="hero" id="home">
        <h1>Study Together, Grow Together!</h1>

        <p>
          Connect with students, create study groups,
          and learn together through group chat.
        </p>

        <button
          className="start-btn"
          onClick={() => setShowGroups(true)}
        >
          Explore Study Groups
        </button>
      </section>

      <section className="groups" id="groups">
        <h2>Popular Study Groups</h2>

        <div className="group-container">
          <div className="group-card">
            <h3>Java Programming</h3>
            <p>Learn Java basics, methods, and OOP concepts.</p>
            <button onClick={() => openChat({
              id: 1,
              name: 'Java Programming'
            })}>
              Join Group
            </button>
          </div>

          <div className="group-card">
            <h3>React Developers</h3>
            <p>Practice React components, hooks, and projects.</p>
            <button onClick={() => openChat({
              id: 2,
              name: 'React Developers'
            })}>
              Join Group
            </button>
          </div>

          <div className="group-card">
            <h3>SQL Learners</h3>
            <p>Practice SQL queries, joins, and subqueries.</p>
            <button onClick={() => openChat({
              id: 3,
              name: 'SQL Learners'
            })}>
              Join Group
            </button>
          </div>
        </div>
      </section>

      <footer id="about">
        <p>© 2026 StudyTogether | Learn and Grow Together</p>
      </footer>
    </div>
  )
}

export default App
