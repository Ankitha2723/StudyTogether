
import { useState } from 'react'
import './App.css'

function Login() {
  const [isRegister, setIsRegister] = useState(false)
  const [username, setUsername] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  function handleSubmit(event) {
    event.preventDefault()

    if (isRegister) {
      alert(`Registration form submitted for ${username}!`)
    } else {
      alert(`Welcome, ${username}!`)
    }
  }

  return (
    <div className="auth-container">
      <form className="auth-card" onSubmit={handleSubmit}>
        <h2>{isRegister ? 'Create Account' : 'Welcome Back!'}</h2>
        <p>
          {isRegister
            ? 'Join StudyTogether today'
            : 'Login to StudyTogether'}
        </p>

        {isRegister && (
          <input
            type="email"
            placeholder="Enter email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        )}

        <input
          type="text"
          placeholder="Enter username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          required
        />

        <input
          type="password"
          placeholder="Enter password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />

        <button type="submit">
          {isRegister ? 'Register' : 'Login'}
        </button>

        <p>
          {isRegister
            ? 'Already have an account?'
            : "Don't have an account?"}
          {' '}
          <span
            onClick={() => setIsRegister(!isRegister)}
            style={{
              color: '#4263eb',
              cursor: 'pointer',
              fontWeight: 'bold',
            }}
          >
            {isRegister ? 'Login' : 'Register'}
          </span>
        </p>
      </form>
    </div>
  )
}

export default Login
